# Company Name Cleanser

This Python tool helps standardize and clean raw company names from an Excel sheet using Google search results via the Serper.dev API.

## 🚀 Features

- Removes repeated words in names (e.g., "Assam Assam" → "Assam")
- Uses top search results from Google (via Serper.dev) to find clean names
- Handles titles ending in "..." and trims location suffixes (India, Mumbai, etc.)
- Saves cleaned names to a new Excel file

## 📂 Folder Structure

```
company-name-cleanser/
├── data/                  # Input Excel file goes here
├── output/                # Cleaned output will be saved here
├── main.py                # Main script
├── requirements.txt       # Dependencies
├── .gitignore             # Ignored files
└── README.md              # Project description
```

## 🛠 Requirements

- Python 3.7+
- Install dependencies with:

```bash
pip install -r requirements.txt
```

## 📈 Usage

1. Put your `companylist.xlsx` in the `data/` folder.
2. Run the script:

```bash
python main.py
```

3. Check the `output/` folder for `cleaned_companies.xlsx`.

## 🔐 API Key

Replace the placeholder key in `main.py` with your actual Serper.dev API key:
https://serper.dev

## 📄 License

MIT License
